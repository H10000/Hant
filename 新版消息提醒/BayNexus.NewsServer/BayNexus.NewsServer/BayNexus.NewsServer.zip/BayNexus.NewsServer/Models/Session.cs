﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BayNexus.NewsServer.Models
{
    class Session
    {
        public string ConnectionID { get; set; }

        public string UserID { get; set; }
    }
}

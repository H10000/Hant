﻿using BayNexus.NewsServer.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BayNexus.NewsServer.BLL
{
    public class DBMessage
    {
        DBHelper db = new DBHelper();
        public void SaveMessage(string messageContent, string messageType, string sendID, string sendName, string receiveID, string receiveName, string sendTime, string sendStatus, string createTime)
        {
            string sql = string.Format(@"insert into messageInfo (MessageContent,messageType,sendID,sendName,receiveID,receiveName,sendTime,sendStatus,createTime)
                                      values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", messageContent, messageType, sendID, sendName, receiveID, receiveName, sendTime, sendStatus, createTime);
            db.MyExecuteInt(sql);
        }

        public DataTable GetMessage(string[] ReceiveIDs = null, string MessageType = null, int SendStatus = 1)
        {
            int DelayMin = ConfigHelper.GetMessageDelayMin == null ? 30 : Convert.ToInt32(ConfigHelper.GetMessageDelayMin);
            DataTable dt = new DataTable();
            string sql = "select * from messageInfo where 1=1  ";
            if (ReceiveIDs != null)
            {
                sql += " and (";
                foreach (string receiveID in ReceiveIDs)
                {
                    sql += "receiveID='" + receiveID + "' or ";
                }
                sql = sql.Remove(sql.Length - 3);
                sql += " )";
            }
            if (MessageType != null)
            {
                sql += " and MessageType='" + MessageType + "'";
            }
            else
            {
                sql += " and (sendTime>='" + DateTime.Now.AddMinutes(-DelayMin) + "' or MessageType='friend' or MessageType='group') ";
            }
            sql += " and sendStatus=" + SendStatus + "";
            sql += " order by messageID asc";
            return db.MyExecuteTable(sql);
        }

        public DataTable GetMessageCurrent(string ReceiveID, string SendID, string MessageType = null, int SendStatus = 2)
        {
            DataTable dt = new DataTable();
            string sql = "select * from messageInfo where 1=1  ";
            if (MessageType == "friend")
            {
                sql += " and ((SendId='" + SendID + "'";
                sql += " and receiveID='" + ReceiveID + "') ";
                sql += " or ";
                sql += "(SendId='" + ReceiveID + "' ";
                sql += " and receiveID='" + SendID + "'))";
            }
            else
            {
                sql += " and SendId='" + SendID + "'";
                sql += " and receiveID='" + ReceiveID + "' ";
            }
            if (MessageType != null)
            {
                sql += " and MessageType='" + MessageType + "'";
            }

            sql += " and sendStatus=" + SendStatus + "";

            sql += " order by SendTime asc";
            return db.MyExecuteTable(sql);
        }

        public void UpdateMessageStatus(int sendStatus, string[] messageIDs)
        {
            string sql = "";
            foreach (string messageID in messageIDs)
            {
                sql += "update messageInfo set sendStatus=" + sendStatus + " where messageID=" + messageID + ";";
            }
            db.MyExecuteInt(sql);
        }
    }
}
